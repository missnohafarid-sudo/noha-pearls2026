import type { MediaChoice } from '../domain/models';
import { HIDDEN_FENCE } from '../domain/slideText';

const HIDE_BUTTON = 'إخفاء المحدَّد';
const TABLE_BUTTON = 'جدول';
const FRACTION_BUTTON = 'كسر';

export const slides = {
  kind: {
    content: 'شريحة شرح',
    choice: 'سؤال اختيار من متعدد',
    text: 'سؤال إجابة مكتوبة',
    media: 'شريحة وسائط',
  },
  field: {
    title: 'العنوان',
    tag: 'الوسم (مرحلة الدرس)',
    badges: 'شارات إضافية (اختياري)',
    badgesHint: 'شارة صغيرة ملوّنة تظهر بجانب الوسم، مثل «الهدف الأول».',
    badgeText: (number: number) => `نص الشارة ${number}`,
    badgeColor: (number: number) => `لون الشارة ${number}`,
    body: 'النص',
    bodyHint: `ابدئي السطر بشرطة (-) ليظهر كنقطة. لإخفاء جزء من النص ظلّليه واضغطي «${HIDE_BUTTON}»، أو ضعي قبله سطرًا فيه ${HIDDEN_FENCE} وبعده سطرًا فيه ${HIDDEN_FENCE}. والسطر الذي فيه رابط صورة فقط (ملف صورة مثل ‎.jpg أو ‎.png أو ‎.gif، أو صورة على Google Drive) يظهر صورة. وللجدول اكتبي كل صف في سطر وافصلي خاناته بالعلامة | ، أو اضغطي «${TABLE_BUTTON}».`,
    images: 'روابط الصور (اختياري)',
    imagesHint: 'الصقي رابطًا عامًّا يبدأ بـ https لكل صورة. ملفات Google Drive يجب أن تكون متاحة لكل من لديه الرابط.',
    image: (number: number) => `رابط الصورة ${number}`,
    hidden: 'معلومة مخفية في آخر الشريحة (اختياري)',
    hiddenHint: 'تُفتح بزر في آخر الشريحة. تُكتب بالتنسيق نفسه، ويمكن أن تضعي فيها رابط صورة في سطر وحده.',
    prompt: 'نص السؤال',
    options: 'الخيارات',
    optionsHint: 'يمكن أن يكون الخيار صورة أو صورة متحركة: الصقي رابطها وحده في خانة الخيار (ملف صورة، أو صورة على Google Drive، أو صفحة من Giphy).',
    option: (letter: string) => `الخيار ${letter}`,
    correct: 'الإجابة الصحيحة',
    noCorrect: 'بدون إجابة صحيحة (استطلاع أو توقّع)',
    explanation: 'التغذية الراجعة (تظهر بعد كشف الإجابة)',
    placeholder: 'نص مساعد داخل خانة الإجابة',
    scope: 'من يجيب؟',
    points: 'النقاط',
    url: 'رابط الوسيط',
    urlHint:
      'الصقي رابطًا عامًّا يبدأ بـ https. ملفات Google Drive يجب أن تكون متاحة لكل من لديه الرابط. إن ظهر الإطار فارغًا أو بوجه حزين فالموقع لا يسمح بعرضه داخل الشريحة؛ يبقى رابط «فتح في نافذة جديدة» تحته.',
    media: 'نوع الوسيط',
  },
  mediaType: {
    auto: 'تلقائي',
    audio: 'صوت',
    image: 'صورة',
    video: 'فيديو',
    pdf: 'ملف PDF',
    embed: 'محاكاة أو صفحة',
  } satisfies Record<MediaChoice, string>,
  tools: {
    symbols: 'رموز',
    hide: HIDE_BUTTON,
    table: TABLE_BUTTON,
    fraction: FRACTION_BUTTON,
    tableHeaders: ['العمود ١', 'العمود ٢'],
    hint: 'ضعي المؤشر في الخانة ثم اختاري الرمز.',
    group: { math: 'رياضيات', powers: 'أسس وأدلة', science: 'علوم' },
  },
  view: {
    send: 'إرسال الإجابة',
    update: 'تحديث الإجابة',
    sent: 'وصلت إجابتكِ. يمكنكِ تعديلها حتى تكشف المعلّمة الإجابة.',
    locked: 'أُغلق السؤال.',
    correct: 'إجابة صحيحة، أحسنتِ!',
    wrong: 'ليست الإجابة الصحيحة. اقرئي التغذية الراجعة.',
    emptySlide: 'شريحة فارغة',
    showHidden: 'إظهار المعلومة',
    hideHidden: 'إخفاء المعلومة',
  },
  media: {
    open: 'فتح في نافذة جديدة',
    frameTitle: 'وسائط الشريحة',
    problem: {
      'no-link': 'لم يُضَف رابط بعد. الصقي رابط الوسيط في خانة «رابط الوسيط».',
      'not-https': 'الرابط يجب أن يبدأ بـ https.',
      'unknown-type': 'تعذّر معرفة نوع هذا الرابط. اختاري النوع من القائمة «نوع الوسيط».',
      'page-link': 'هذا رابط صفحة وليس رابط الصورة نفسها. اضغطي على الصورة بزر الفأرة الأيمن، اختاري «نسخ عنوان الصورة»، ثم الصقيه هنا.',
    },
    viewerProblem: 'تعذّر عرض هذا الوسيط.',
    loadFailedTeacher: 'تعذّر تحميل الوسيط. تحقّقي من أن الرابط يعمل وأنه متاح لكل من لديه الرابط، أو غيّري «نوع الوسيط».',
    zoomOut: 'تصغير',
    zoomIn: 'تكبير',
    zoomLevel: (percent: number) => `${percent}%`,
  },
} as const;

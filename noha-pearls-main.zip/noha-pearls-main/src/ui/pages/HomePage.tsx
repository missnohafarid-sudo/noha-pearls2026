import { useEffect, useRef, useState } from 'react';
import type { FolderTree } from '../../domain/folders';
import type { Id, SiteContent } from '../../domain/models';
import { t } from '../../i18n';
import logoRose from '../assets/brand/logo-rose.jpg';
import { Loading } from '../common/PageState';
import type { FieldSpec } from '../forms/SchemaForm';
import { SchemaForm } from '../forms/SchemaForm';
import { Tip } from '../common/Tip';
import { useAdmin, useAnyLive, useAsked, useLiveSessions, useSite, useTeachers } from '../hooks/data';
import { useSiteEdits } from '../hooks/useSiteEdits';
import { JoinByCode } from '../join/JoinByCode';
import { LessonImportDialog } from '../lesson/LessonImportDialog';
import { ClearingNotice } from '../retention/ClearingNotice';
import { ManagedLibrary } from '../library/ManagedLibrary';
import { pathText } from '../library/place';
import { PublicLibrary } from '../library/PublicLibrary';
import { useLibraryView, type LibraryView } from '../library/useLibraryView';
import { useAttempt } from '../common/useAttempt';
import { homeRoute, navigate } from '../routing/routes';
import { useRoute } from '../routing/useRoute';
import { LiveSessionList } from '../session/SessionLists';
import { TeachersPanel } from '../session/TeachersPanel';
import { useServices } from '../ServicesContext';
import { AdminPanel } from '../shell/AdminPanel';
import './home.css';

const th = t.home;
const tl = t.library;

/** The part of the site record the home form owns; every other field of the record is left as it is found. */
type SiteText = Pick<SiteContent, 'schoolName' | 'title' | 'tagline' | 'intro'>;

const siteText = ({ schoolName, title, tagline, intro }: SiteContent): SiteText => ({ schoolName, title, tagline, intro });

const changedFields = (before: SiteText, after: SiteText): Partial<SiteText> =>
  Object.fromEntries(Object.entries(after).filter(([key, value]) => value !== before[key as keyof SiteText]));

const SITE_FIELDS: readonly FieldSpec<SiteText>[] = [
  { kind: 'text', key: 'schoolName', label: th.siteField.schoolName },
  { kind: 'text', key: 'title', label: th.siteField.title },
  { kind: 'text', key: 'tagline', label: th.siteField.tagline },
  { kind: 'textarea', key: 'intro', label: th.siteField.intro },
];

function TeacherNames() {
  const teachers = useTeachers();
  if (!teachers?.length) return null;
  return <p className="muted">{th.teachersLine(teachers.map((teacher) => teacher.name))}</p>;
}

function VisitorJoin() {
  const live = useAnyLive();
  const admin = useAdmin();
  if (!live || admin) return null;
  return (
    <section className="stack stack--tight">
      <p className="notice">{th.liveNowVisitor}</p>
      <JoinByCode />
    </section>
  );
}

function AdminLiveNotice() {
  const live = useLiveSessions();
  const admin = useAdmin();
  if (!live?.length || !admin) return null;
  return (
    <div className="notice">
      <LiveSessionList sessions={live} page="session" />
    </div>
  );
}

function HomeAdminPanels({ site, tree, openId }: { site: SiteContent; tree: FolderTree | undefined; openId: Id | null }) {
  const { lessons } = useServices();
  const [importing, setImporting] = useState(false);

  const { error, attemptWith } = useAttempt();
  const { edit, error: siteError } = useSiteEdits();
  const shown = useRef(siteText(site));
  const editSite = (next: SiteText) => {
    edit(changedFields(shown.current, next));
    shown.current = next;
  };

  const create = async () => {
    const made = await attemptWith(() => lessons.create(th.panel.newLessonTitle, openId));
    if (made) navigate({ name: 'lesson', lessonId: made.value.id, slideIndex: 0 });
  };

  return (
    <>
      <AdminPanel title={th.panel.site}>
        <SchemaForm fields={SITE_FIELDS} value={siteText(site)} resetKey="site" onChange={editSite} />
        {siteError && <p className="notice notice--bad">{siteError}</p>}
      </AdminPanel>
      <TeachersPanel />
      <AdminPanel title={th.panel.lessons}>
        <div className="stack stack--tight">
          <button type="button" className="btn btn--primary" onClick={() => void create()}>
            {th.panel.newLesson}
          </button>
          <button type="button" className="btn" onClick={() => setImporting(true)}>
            {th.panel.importLesson}
          </button>
          {error && <p className="notice notice--bad">{error}</p>}
          {tree && <p className="muted">{tl.keptIn(pathText(tree, openId))}</p>}
        </div>
        {importing && <LessonImportDialog folderId={openId} onClose={() => setImporting(false)} />}
      </AdminPanel>
    </>
  );
}

/** A dot at the end of the note whose tip says where the hub runs; none where there is no hub to ask, or while it cannot say. */
function HubPlaceDot() {
  const { hubPlace } = useServices();
  const code = useAsked(() => hubPlace.code().catch(() => null), [hubPlace]);
  if (!code) return null;
  return (
    <Tip text={th.hubPlace(code)}>
      <span className="data-note__dot" />
      <span className="visually-hidden">{th.hubPlaceName}</span>
    </Tip>
  );
}

/** The note at the foot of the home page. On a phone it runs across its own lane in one line, like a news ticker, so the copy after it closes the loop. */
function DataNote() {
  return (
    <footer className="data-note">
      <div className="data-note__lane">
        <p className="data-note__track">
          <span>{th.dataNote}</span>
          <span aria-hidden="true">{th.dataNote}</span>
        </p>
      </div>
      <HubPlaceDot />
    </footer>
  );
}

function Library({ view, openId }: { view: LibraryView; openId: Id | null }) {
  const open = (folderId: Id | null) => navigate(homeRoute(folderId));
  return view.admin ? <ManagedLibrary view={view} openId={openId} onOpen={open} /> : <PublicLibrary view={view} openId={openId} onOpen={open} />;
}

/** The public front page: a visitor's way into a live class, the school hero and the lessons. */
export function HomePage() {
  const site = useSite();
  const route = useRoute();
  const view = useLibraryView('browse');
  const requestedId = route.name === 'home' ? route.folderId : undefined;
  const openId = view?.folderToShow(requestedId) ?? null;
  const addressIsDead = view !== undefined && requestedId !== undefined && openId === null;

  useEffect(() => {
    if (addressIsDead) navigate(homeRoute(null), { replace: true });
  }, [addressIsDead]);

  if (!site) return <Loading />;
  return (
    <div className="page">
      <VisitorJoin />
      <header className="hero pearl-veil">
        <div className="hero__text">
          <span className="chip chip--accent">{site.schoolName}</span>
          <h1 className="page__title rose-gold">{site.title}</h1>
          <p className="hero__tagline">{site.tagline}</p>
          <p>{site.intro}</p>
          <TeacherNames />
        </div>
        <img className="hero__poster" src={logoRose} alt={site.title} width={1296} height={830} />
      </header>
      <AdminLiveNotice />
      <ClearingNotice />
      <section className="stack">
        <h2>{th.lessonsTitle}</h2>
        {view ? <Library view={view} openId={openId} /> : <Loading />}
      </section>
      <HomeAdminPanels site={site} tree={view?.tree} openId={openId} />
      <DataNote />
    </div>
  );
}
